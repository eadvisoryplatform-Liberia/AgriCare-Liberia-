# Changelog

## Update
- Main menu regrouped into four sections: Ask and learn, Any phone no internet, Food security and support, For partners. All 13 entries kept.
- Cleaner cards, buttons and header, hover and press effects, clearer keyboard focus, reduced-motion support.
- Removed the duplicate "AgriCare-Liberia · Farming For All" line from the landing hero (it is already in the top left).
- No features, data, images or audio were removed.
