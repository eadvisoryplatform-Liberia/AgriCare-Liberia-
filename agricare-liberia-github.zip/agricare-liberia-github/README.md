# AgriCare-Liberia · Farming For All

Farming for all, even on a basic phone. Market prices, planting and pest advice, and food security help by app, SMS and voice.

Designed and developed by **Team 8, E-Advisory**.

## Features

**Ask and learn**
- AI assistant: answers from the app library and, when online, from the web
- Farm hub: crops, weather, scan and market in one place
- Advisory library: crop and livestock questions and answers, read aloud
- Voice library: advisories with audio in Liberian languages (16 listed; Mende, Kpelle, Kru and Vai have recordings)
- Plant scan: plant type, use, disease, health and fix from 1 to 3 photos

**Any phone, no internet**
- Call 1234 (voice AI helpline, practice mode)
- SMS menu: text 1234 and follow the numbered menu (test mode, nothing is sent)
- USSD menu for any phone

**Food security and support**
- Household food check, shared with the Ministry
- Get help: send a request to an extension officer

**For partners**
- Extension officer tools
- Agribusiness supply and demand
- Ministry dashboard and alerts

## Run it

It is a single self-contained file. Open `index.html` in a browser, or host it with GitHub Pages:

1. Repository **Settings → Pages**
2. Source: **Deploy from a branch**, branch `main`, folder `/ (root)`
3. Open the published link (HTTPS is needed for microphone and camera features)

## Repository layout

```
index.html    the whole app (code, images and audio embedded)
README.md     this file
CHANGELOG.md  what changed
.nojekyll     tells GitHub Pages to serve the file as is
```

Note: `index.html` is about 7.5 MB because the audio recordings are embedded. This is within GitHub's file limits.
