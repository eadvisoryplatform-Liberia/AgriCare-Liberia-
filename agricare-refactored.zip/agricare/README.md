# AgriCare-Liberia · Farming For All

A demo food-security and farm-advisory platform for Liberian farmers: an SMS/USSD-style menu for basic phones, a web app with role-based dashboards (farmer, extension officer, agribusiness, ministry), a Farmer Hub, and local-language voice advisories.

No build step, no dependencies. It is plain HTML, CSS and JavaScript.

## Run it

**Quickest:** open `index.html` in a browser (double-click it).

**Or with a local server** (closer to how it behaves online):

```bash
python3 -m http.server 8000
# then visit http://localhost:8000
```

## Put it online (GitHub Pages)

1. Push this folder to a GitHub repository.
2. Go to **Settings → Pages**.
3. Under **Build and deployment**, choose **Deploy from a branch**, pick `main` and `/ (root)`, then Save.
4. Your site appears at `https://<your-username>.github.io/<repo-name>/`.

## Project structure

```
index.html            Landing page: SMS simulator, staff demo, voice advice
css/style.css         Landing page styles
js/data.js            Crops, pests, advisories, counties, prices (edit content here)
js/menu-engine.js     The SMS/USSD menu logic
js/main.js            Landing page behaviour (chat simulator, overlay, voice button)

app/index.html        The web app (opens in an overlay from the landing page)
app/css/app.css       App styles
app/js/app.js         App logic: accounts, dashboards, voice library, plant scan
app/hub.html          Farmer Hub (markets, weather, pests, soil), loaded inside the app

assets/               Logo, hero image, and audio
assets/audio/         Local-language voice advisories (Mende, Kpelle)
```

## Code structure

Scripts are plain browser scripts (no build step, and they still work from `file://`). Each registers on a single `AgriCare` namespace:

| Module | Namespace | Responsibility |
|---|---|---|
| `js/data.js` | `AgriCare.data` | Read-only content (counties, crops, pests, advisories, prices) |
| `js/menu-engine.js` | `AgriCare.menu` | Stateless SMS/USSD menu: `run(inputs, hooks)` replays a session and returns the next screen |
| `js/main.js` | none | UI classes: `SmsGateway`, `ChatSimulator`, `VoicePlayer`, `StaffPanel`, `AppOverlay` |

## Common edits

| I want to change...              | Edit this file                  |
|----------------------------------|---------------------------------|
| Crop guides, pest tips, prices   | `js/data.js`                    |
| SMS menu wording and flow        | `js/menu-engine.js`             |
| Landing page text and layout     | `index.html`, `css/style.css`   |
| App screens and roles            | `app/js/app.js`, `app/css/app.css` |
| Farmer Hub                       | `app/hub.html`                  |
| Voice audio                      | replace files in `assets/`      |

## Good to know

- **Demo data only.** Accounts, requests and stats are stored in each visitor's own browser (`localStorage`). Nothing is sent to a real phone or server, and the SMS and advisory features are simulated.
- **Plant scan** lets a user paste their own Anthropic API key, which is kept only in their browser. Never commit API keys to this repository.
- **Google sign-in** is switched off until a client ID is set in `app/js/app.js` (`GCID`).
- The Farmer Hub checks for an optional backend at `api/health`. On static hosting this returns a 404, which is expected and harmless.

## Contributing

1. Fork the repository and create a branch.
2. Make your change and test it by opening `index.html` in a browser.
3. Open a pull request describing what you changed.
